/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Task Service
 * File: TaskServiceTest.java
 *
 * This file contains JUnit tests for the TaskService class.
 * Tests cover adding, retrieving, updating, and deleting tasks,
 * including error handling for duplicate IDs.
 */

package tasks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    // --- Add a single task ---
    @Test
    void addTask_addsSingleTaskSuccessfully() {
        Task t = new Task("BAT01", "Patrol Gotham", "Night sweep around the Narrows.");
        service.addTask(t);

        Task fetched = service.getTask("BAT01");
        assertNotNull(fetched);
        assertEquals("BAT01", fetched.getTaskId());
        assertEquals("Patrol Gotham", fetched.getName());
        assertEquals("Night sweep around the Narrows.", fetched.getDescription());
    }

    // --- Add multiple tasks ---
    @Test
    void addTask_addsMultipleDistinctTasksSuccessfully() {
        service.addTask(new Task("SUP02", "Daily Planet", "Clark drafts an op-ed."));
        service.addTask(new Task("WW03", "Train Amazons", "Drills on Themyscira."));
        service.addTask(new Task("FLASH04", "Forensics Report", "Barry files CCPD report."));

        assertNotNull(service.getTask("SUP02"));
        assertNotNull(service.getTask("WW03"));
        assertNotNull(service.getTask("FLASH04"));
    }

    // --- Duplicate ID should error ---
    @Test
    void addTask_withDuplicateId_throws() {
        service.addTask(new Task("BAT01", "Patrol Gotham", "Initial route."));

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () ->
            service.addTask(new Task("BAT01", "Second Shift", "Duplicate ID attempt."))
        );
        assertTrue(ex.getMessage().toLowerCase().contains("exists"));
    }

    // --- Add via convenience overload and get back ---
    @Test
    void addTask_overloadCreatesAndReturnsStoredTask() {
        Task created = service.addTask("CYB06", "System Patch", "Victor applies OS update.");
        Task fetched = service.getTask("CYB06");

        assertNotNull(created);
        assertNotNull(fetched);
        assertSame(fetched, created);
        assertEquals("System Patch", fetched.getName());
    }

    // --- Update name & description by ID ---
    @Test
    void update_updatesNameAndDescriptionSuccessfully() {
        service.addTask("WW03", "Train Amazons", "Morning drills.");
        service.updateTaskName("WW03", "Arena Drills");
        service.updateTaskDescription("WW03", "Diana leads advanced arena combat training.");

        Task t = service.getTask("WW03");
        assertEquals("Arena Drills", t.getName());
        assertEquals("Diana leads advanced arena combat training.", t.getDescription());
    }

    // --- Update fails for missing ID or invalid values ---
    @Test
    void update_withMissingIdOrInvalidValues_throws() {
        // Missing ID
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("NOPE", "X"));
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("NOPE", "X"));

        // Present task but invalid updates
        service.addTask("FLASH04", "Forensics Report", "Barry files CCPD report.");
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("FLASH04", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("FLASH04", "CoordinateAmbassadorSummit")); // > 20
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("FLASH04", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("FLASH04", "Y".repeat(51))); // > 50
    }

    // --- Delete by ID ---
    @Test
    void delete_removesTaskById() {
        service.addTask("AQ05", "Trident Maintenance", "Inspect prongs for micro-fractures.");
        assertTrue(service.deleteTask("AQ05"));    // removed
        assertFalse(service.deleteTask("AQ05"));   // already gone
        assertNull(service.getTask("AQ05"));       // not found
    }
}
