/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Task Service
 * File: TaskTest.java
 *
 * This file contains JUnit tests for the Task class.
 * Tests confirm that field validation works correctly
 * and invalid data is rejected.
 */

package tasks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    // Helper to build a string of length
    private static String nChars(char c, int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) sb.append(c);
        return sb.toString();
    }

    // --- Happy path: creating a valid Task ---
    @Test
    void createTask_withValidFields_setsValues() {
        Task t = new Task(
            "BAT01",
            "Patrol Gotham",
            "Batman night patrol around the Narrows."
        );

        assertEquals("BAT01", t.getTaskId());
        assertEquals("Patrol Gotham", t.getName());
        assertEquals("Batman night patrol around the Narrows.", t.getDescription());
    }

    // --- ID validations ---
    @Test
    void constructor_withNullId_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, "Forensics Report", "Barry files CCPD report for case #52.")
        );
    }

    @Test
    void constructor_withTooLongId_throws() {
        // 11 characters: exceeds max of 10
        assertThrows(IllegalArgumentException.class, () ->
            new Task("SUPERMAN001", "Daily Planet", "Clark Kent writes front-page article.")
        );
    }

    // --- Name validations ---
    @Test
    void constructor_withNullName_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("WW03", null, "Diana leads combat training on Themyscira.")
        );
    }

    @Test
    void constructor_withTooLongName_throws() {
        // 21 characters (max allowed is 20)
        String longName = "RefactorWidgetRenderer";
        assertThrows(IllegalArgumentException.class, () ->
            new Task("FLASH04", longName, "Barry optimizes CSI tooling for case backlog.")
        );
    }

    // --- Description validations ---
    @Test
    void constructor_withNullDescription_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("AQ05", "Trident Maintenance", null)
        );
    }

    @Test
    void constructor_withTooLongDescription_throws() {
        String longDesc = nChars('X', 51); // > max 50
        assertThrows(IllegalArgumentException.class, () ->
            new Task("CYB06", "System Patch", longDesc)
        );
    }

    // --- Updaters: name & description are updatable and validated ---
    @Test
    void setters_updateNameAndDescription_whenValid() {
        Task t = new Task("SUP02", "Daily Planet", "Clark drafts an op-ed.");

        t.setName("Interview Perry");
        t.setDescription("Clark interviews Perry White for newsroom story.");

        assertEquals("SUP02", t.getTaskId());
        assertEquals("Interview Perry", t.getName());
        assertEquals("Clark interviews Perry White for newsroom story.", t.getDescription());
    }

    @Test
    void setters_withInvalidValues_throw() {
        Task t = new Task("WW03", "Train Amazons", "Diana leads warrior drills.");

        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
        assertThrows(IllegalArgumentException.class, () -> t.setName("CoordinateAmbassadorSummit")); // > 20
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(nChars('Y', 51))); // > 50
    }

    // --- ID immutability ---
    @Test
    void id_isNotUpdatable_andRemainsConstant() {
        Task t = new Task("BAT01", "Patrol Gotham", "City sweep from Midtown to the Narrows.");
        String idBefore = t.getTaskId();

        // Keep updated name ≤ 20 chars to satisfy validation
        t.setName("Patrol (Late Shift)");
        t.setDescription("Coordinate with Gordon; sweep Lower Gotham.");

        assertEquals(idBefore, t.getTaskId());
    }
}