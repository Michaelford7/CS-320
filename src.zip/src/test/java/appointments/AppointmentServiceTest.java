/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Appointment Service
 * File: AppointmentServiceTest.java
 *
 * Tests for the AppointmentService class.
 * Checks adding and deleting appointments and common errors.
 */

package appointments;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

class AppointmentServiceTest {

    private AppointmentService service;

    // helper to get a time in the future
    private static Date futureDate() {
        return new Date(System.currentTimeMillis() + 60_000); // 1 minute ahead
    }

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @Test
    void addAppointment_objectVersion_addsOnce() {
        Appointment a = new Appointment("BAT01", futureDate(), "Meeting with Lucius Fox");
        service.addAppointment(a);
        assertEquals(1, service.size());
        assertNotNull(service.getAppointment("BAT01"));
    }

    @Test
    void addAppointment_stringVersion_addsOnce() {
        service.addAppointment("BAT02", futureDate(), "Batsignal test run");
        assertEquals(1, service.size());
        assertNotNull(service.getAppointment("BAT02"));
    }

    @Test
    void addAppointment_duplicateId_throws() {
        service.addAppointment("BAT03", futureDate(), "Wayne Enterprises board call");
        assertThrows(IllegalArgumentException.class,
                () -> service.addAppointment("BAT03", futureDate(), "Duplicate attempt"));
    }

    @Test
    void addAppointment_nullObject_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> service.addAppointment((Appointment) null));
    }

    @Test
    void deleteAppointment_existingId_removesIt() {
        service.addAppointment("BAT04", futureDate(), "GCPD coordination");
        service.deleteAppointment("BAT04");
        assertEquals(0, service.size());
        assertNull(service.getAppointment("BAT04"));
    }

    @Test
    void deleteAppointment_missingId_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteAppointment("NO_SUCH_ID"));
    }

    @Test
    void deleteAppointment_nullId_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteAppointment(null));
    }
}
