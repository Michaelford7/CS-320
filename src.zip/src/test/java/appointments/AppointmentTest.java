/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Appointment Service
 * File: AppointmentTest.java
 *
 * Tests for the Appointment class.
 * Checks valid creation and all validation rules.
 */

package appointments;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

class AppointmentTest {

    // helper to get a time in the future
    private static Date futureDate() {
        return new Date(System.currentTimeMillis() + 60_000); // 1 minute ahead
    }

    @Test
    void create_withValidFields_works() {
        Appointment a = new Appointment("BAT01", futureDate(), "Wayne Enterprises briefing");
        assertEquals("BAT01", a.getAppointmentId());
        assertEquals("Wayne Enterprises briefing", a.getDescription());
        assertTrue(a.getAppointmentDate().getTime() > System.currentTimeMillis());
    }

    @Test
    void id_null_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, futureDate(), "Villain roundup"));
    }

    @Test
    void id_over10Chars_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("ABCDEFGHIJK", futureDate(), "Too long id"));
    }

    @Test
    void date_null_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("BAT02", null, "Batcave maintenance"));
    }

    @Test
    void date_inPast_throws() {
        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("BAT03", past, "Alfred tea time"));
    }

    @Test
    void description_null_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("BAT04", futureDate(), null));
    }

    @Test
    void description_over50Chars_throws() {
        String fiftyOne = "x".repeat(51);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("BAT05", futureDate(), fiftyOne));
    }

    @Test
    void setters_enforceRules_andDateIsDefensiveCopy() {
        Appointment a = new Appointment("BAT06", futureDate(), "Patrol plan");

        // valid description update
        a.setDescription("Narrows sweep");
        assertEquals("Narrows sweep", a.getDescription());

        // too-long description rejected
        assertThrows(IllegalArgumentException.class,
                () -> a.setDescription("x".repeat(51)));

        // past date rejected
        assertThrows(IllegalArgumentException.class,
                () -> a.setAppointmentDate(new Date(System.currentTimeMillis() - 1000)));

        // getter returns a copy so outside change doesn't affect the object
        Date copy = a.getAppointmentDate();
        copy.setTime(System.currentTimeMillis() - 10_000);
        assertTrue(a.getAppointmentDate().getTime() > System.currentTimeMillis());
    }
}
