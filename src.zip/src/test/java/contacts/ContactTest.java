/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Contact Service
 * File: ContactTest.java
 *
 * This file contains JUnit tests for the Contact class.
 * Tests confirm that field validation works correctly
 * and invalid data is rejected.
 */

package contacts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactTest {

    // Valid contact
    @Test
    void testValidContactCreation() {
        Contact c = new Contact("MF001", "Michael", "Ford", "2055551212", "Alabama");
        assertEquals("MF001", c.getContactId());
        assertEquals("Michael", c.getFirstName());
        assertEquals("Ford", c.getLastName());
        assertEquals("2055551212", c.getPhone());
        assertEquals("Alabama", c.getAddress());
    }

    // Contact ID is null (Bruce Wayne) should throw error
    @Test
    void testIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Bruce", "Wayne", "1234567890", "Gotham");
        });
    }

    // Contact ID too long (Clark Kent, 11 characters) should throw error
    @Test
    void testIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Clark", "Kent", "9998887777", "Kansas");
        });
    }

    // First name is null (Hal Jordan) should throw error
    @Test
    void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("GL001", null, "Jordan", "2055551212", "Coast City");
        });
    }

    // First name too long (Barry Allen, deliberately "BarryBarryBarry") should throw error
    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("FL001", "BarryBarryBarry", "Allen", "2055551212", "Central City");
        });
    }

    // Last name is null (Diana Prince) should throw error
    @Test
    void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("WW001", "Diana", null, "2055551212", "Themyscira");
        });
    }

    // Last name too long (Oliver Queen, deliberately "QueenQueenQueen") should throw error
    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("GA001", "Oliver", "QueenQueenQueen", "2055551212", "Star City");
        });
    }

    // Address is null (Billy Batson) should throw error
    @Test
    void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("SHA001", "Billy", "Batson", "2055551212", null);
        });
    }

    // Address too long (Kara Zor-El, deliberately 31 characters) should throw error
    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("SG001", "Kara", "Zor-El", "1234567890", "1234567890123456789012345678901");
        });
    }

    // Phone too short (Lois Lane, only 5 digits) should throw error
    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("LOIS01", "Lois", "Lane", "12345", "Metropolis");
        });
    }

    // Phone too long (Victor Stone, 13 digits) should throw error
    @Test
    void testPhoneTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("CYB001", "Victor", "Stone", "1234567890123", "Detroit");
        });
    }

    // Phone has letters (Arthur Curry, "12345ABCDE") should throw error
    @Test
    void testPhoneWithLetters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("AQ001", "Arthur", "Curry", "12345ABCDE", "Atlantis");
        });
    }

    // Update fields (Shiera Sanders, changed after creation)
    @Test
    void testUpdateFields() {
        Contact c = new Contact("HAWK01", "Shiera", "Sanders", "9998887777", "St. Roch");
        c.setFirstName("Hawkgirl");   // update first name
        c.setLastName("Hero");        // update last name
        c.setPhone("1112223333");     // update phone
        c.setAddress("New York");     // update address
        assertEquals("Hawkgirl", c.getFirstName());
        assertEquals("Hero", c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("New York", c.getAddress());
    }
}
