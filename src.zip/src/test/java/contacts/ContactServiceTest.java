/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Contact Service
 * File: ContactServiceTest.java
 *
 * This file contains JUnit tests for the ContactService class.
 * Tests confirm that adding, deleting, and updating contacts
 * works correctly and handles edge cases.
 */

package contacts;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    // Add a single contact
    @Test
    void testAddSingleContact() {
        Contact c = new Contact("MF001", "Michael", "Ford", "2055551212", "Alabama");
        service.addContact(c);
        assertEquals(c, service.getById("MF001"));
    }

    // Add multiple contacts
    @Test
    void testAddMultipleContacts() {
        Contact tony = new Contact("IRON01", "Tony", "Stark", "1112223333", "California");
        Contact steve = new Contact("CAP01", "Steve", "Rogers", "4445556666", "New York");
        service.addContact(tony);
        service.addContact(steve);
        assertEquals(2, service.getAll().size());
    }

    // Duplicate ID should fail
    @Test
    void testDuplicateIdThrowsError() {
        Contact thor1 = new Contact("THOR01", "Thor", "Odinson", "7778889999", "Asgard");
        Contact thor2 = new Contact("THOR01", "Thor", "Odinson", "1234567890", "Asgard");
        service.addContact(thor1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(thor2));
    }

    // Add and get back by ID
    @Test
    void testGetById() {
        Contact hulk = new Contact("HULK01", "Bruce", "Banner", "9991112222", "Gamma Fields");
        service.addContact(hulk);
        assertNotNull(service.getById("HULK01"));
        assertEquals("Bruce", service.getById("HULK01").getFirstName());
    }

    // Update first name
    @Test
    void testUpdateFirstName() {
        Contact spidey = new Contact("SPID01", "Peter", "Parker", "1231231234", "New York");
        service.addContact(spidey);
        service.updateFirstName("SPID01", "Wolverine");
        assertEquals("Wolverine", service.getById("SPID01").getFirstName());
    }

    // Update last name
    @Test
    void testUpdateLastName() {
        Contact gambit = new Contact("GAM01", "Remy", "LeBeau", "2223334444", "Louisiana");
        service.addContact(gambit);
        service.updateLastName("GAM01", "Gambit");
        assertEquals("Gambit", service.getById("GAM01").getLastName());
    }

    // Update phone
    @Test
    void testUpdatePhone() {
        Contact widow = new Contact("WID01", "Natasha", "Romanoff", "3334445555", "Russia");
        service.addContact(widow);
        service.updatePhone("WID01", "5556667777");
        assertEquals("5556667777", service.getById("WID01").getPhone());
    }

    // Update address
    @Test
    void testUpdateAddress() {
        Contact thanos = new Contact("THAN01", "Thanos", "Titan", "8889990000", "Titan Moon");
        service.addContact(thanos);
        service.updateAddress("THAN01", "New York");
        assertEquals("New York", service.getById("THAN01").getAddress());
    }

    // Delete a contact
    @Test
    void testDeleteContact() {
        Contact stan = new Contact("STAN01", "Stan", "Lee", "1010101010", "New York");
        service.addContact(stan);
        assertTrue(service.deleteContact("STAN01"));
        assertNull(service.getById("STAN01"));
    }

    // Update non-existent contact
    @Test
    void testUpdateNonExistentContactThrowsError() {
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("FAKE01", "Nobody"));
    }

    // Another add test with Doctor Strange
    @Test
    void testAddDoctorStrange() {
        Contact strange = new Contact("STR01", "Steven", "Strange", "1212121212", "New York");
        service.addContact(strange);
        assertEquals("Steven", service.getById("STR01").getFirstName());
    }

    // Add Charles Xavier
    @Test
    void testAddProfessorX() {
        Contact xavier = new Contact("XAV01", "Charles", "Xavier", "1313131313", "New York");
        service.addContact(xavier);
        assertEquals("Xavier", service.getById("XAV01").getLastName());
    }
}