/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Contact Service
 * File: ContactService.java
 *
 * This class manages Contact objects in memory using a HashMap.
 * It supports adding with unique IDs, deleting by ID, and
 * updating specific fields by ID (firstName, lastName, phone, address).
 */

package contacts;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * ContactService provides in-memory management of Contact objects.
 * - addContact(Contact): adds a contact if the ID is unique
 * - deleteContact(String): deletes by contact ID
 * - updateFirstName / updateLastName / updatePhone / updateAddress: update by ID
 */
public class ContactService {

    // In-memory store keyed by contactId
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Add a new contact.
     * @param contact Contact to add (must not be null)
     * @throws IllegalArgumentException if contact is null or ID already exists
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("contact cannot be null");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            // “error occurs when adding a contact with a duplicate ID”
            throw new IllegalArgumentException("contactId already exists: " + id);
        }
        contacts.put(id, contact);
    }

    /**
     * Delete a contact by its ID.
     * @param contactId the ID to remove
     * @return true if a contact was removed; false if not found
     */
    public boolean deleteContact(String contactId) {
        return contacts.remove(contactId) != null;
    }

    // Update operations

    /**
     * Update the first name for a contact by ID.
     * @throws IllegalArgumentException if no contact with that ID exists
     */
    public void updateFirstName(String contactId, String newFirstName) {
        Contact c = require(contactId);
        c.setFirstName(newFirstName); // Contact validates length/non-null
    }

    /**
     * Update the last name for a contact by ID.
     * @throws IllegalArgumentException if no contact with that ID exists
     */
    public void updateLastName(String contactId, String newLastName) {
        Contact c = require(contactId);
        c.setLastName(newLastName);
    }

    /**
     * Update the phone number for a contact by ID.
     * @throws IllegalArgumentException if no contact with that ID exists
     */
    public void updatePhone(String contactId, String newPhone) {
        Contact c = require(contactId);
        c.setPhone(newPhone); // Contact enforces exactly 10 digits
    }

    /**
     * Update the address for a contact by ID.
     * @throws IllegalArgumentException if no contact with that ID exists
     */
    public void updateAddress(String contactId, String newAddress) {
        Contact c = require(contactId);
        c.setAddress(newAddress);
    }

    //Convenience getters

    /** Returns the contact by ID, or null if not found. */
    public Contact getById(String contactId) {
        return contacts.get(contactId);
    }

    /** Reads only snapshot of all contacts. */
    public Map<String, Contact> getAll() {
        return Collections.unmodifiableMap(contacts);
    }

    // Internal helper
    private Contact require(String contactId) {
        Contact c = contacts.get(contactId);
        if (c == null) {
            throw new IllegalArgumentException("No contact found for id: " + contactId);
        }
        return c;
    }
}
