/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Contact Service
 * File: Contact.java
 *
 * This class defines the Contact object for the project.
 * It enforces requirements such as field length limits,
 * phone number format, and non-null values.
 */

package contacts;

/**
 * Contact represents one contact record with validation rules.
 * Rules:
 * - contactId: required, not null, <= 10 chars, NOT updatable
 * - firstName: required, not null, <= 10 chars
 * - lastName : required, not null, <= 10 chars
 * - phone    : required, not null, exactly 10 digits (0-9)
 * - address  : required, not null, <= 30 chars
 */
public class Contact {

    // ID cannot change after creation
    private final String contactId;

    // These fields can be updated
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructor to create a new contact.
     * All fields are validated before assignment.
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = validateId(contactId);
        this.firstName = validateName(firstName, "firstName", 10);
        this.lastName  = validateName(lastName, "lastName", 10);
        this.phone     = validatePhone(phone);
        this.address   = validateAddress(address);
    }

    // Getters (no setter for contactId since it must never change)
    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
    public String getPhone()     { return phone; }
    public String getAddress()   { return address; }

    // Setters for fields with validation
    public void setFirstName(String firstName) {
        this.firstName = validateName(firstName, "firstName", 10);
    }

    public void setLastName(String lastName) {
        this.lastName = validateName(lastName, "lastName", 10);
    }

    // “Number” in the requirements = phone
    public void setPhone(String phone) {
        this.phone = validatePhone(phone);
    }

    public void setAddress(String address) {
        this.address = validateAddress(address);
    }

    // Validation helper methods

    private static String validateId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("contactId must be non-null and <= 10 characters");
        }
        return id;
    }

    private static String validateName(String value, String field, int maxLen) {
        if (value == null || value.length() > maxLen) {
            throw new IllegalArgumentException(field + " must be non-null and <= " + maxLen + " characters");
        }
        return value;
    }

    private static String validatePhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("phone must be exactly 10 digits");
        }
        return phone;
    }

    private static String validateAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("address must be non-null and <= 30 characters");
        }
        return address;
    }
}