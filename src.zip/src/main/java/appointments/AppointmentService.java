/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Appointment Service
 * File: AppointmentService.java
 *
 * This class manages Appointment objects in memory.
 * It allows adding and deleting appointments by ID.
 */

package appointments;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;

public class AppointmentService {

    // store appointments in a map with the id as the key
    private final Map<String, Appointment> store = new HashMap<>();

    // add an appointment object
    public void addAppointment(Appointment appt) {
        if (appt == null) throw new IllegalArgumentException("Appointment cannot be null.");
        String id = appt.getAppointmentId();
        if (store.containsKey(id)) throw new IllegalArgumentException("Appointment ID already exists.");
        store.put(id, appt);
    }

    // add by passing fields directly
    public void addAppointment(String id, Date date, String description) {
        addAppointment(new Appointment(id, date, description));
    }

    // delete appointment by id
    public void deleteAppointment(String id) {
        if (id == null) throw new IllegalArgumentException("ID cannot be null.");
        if (store.remove(id) == null) {
            throw new IllegalArgumentException("No appointment found with this ID.");
        }
    }

    // helper methods for tests or future use
    public Appointment getAppointment(String id) { 
        return store.get(id); 
    }

    public Collection<Appointment> getAllAppointments() { 
        return Collections.unmodifiableCollection(store.values()); 
    }

    public int size() { 
        return store.size(); 
    }
}
