/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Appointment Service
 * File: Appointment.java
 *
 * This class defines the Appointment object for the project.
 * It checks for null values, length limits, and makes sure
 * the appointment date is not set in the past.
 */

package appointments;

import java.util.Date;
import java.util.Objects;

public class Appointment {

    // id must be 10 characters or less and cannot change
    private final String appointmentId;

    // date cannot be null or in the past
    private Date appointmentDate;

    // description must be 50 characters or less
    private String description;

    // constructor sets all required fields
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        validateId(appointmentId);
        setAppointmentDateInternal(appointmentDate);
        setDescriptionInternal(description);
        this.appointmentId = appointmentId;
    }

    // getters
    public String getAppointmentId() { 
        return appointmentId; 
    }

    public Date getAppointmentDate() { 
        // return copy so outside code can’t change it directly
        return new Date(appointmentDate.getTime()); 
    }

    public String getDescription() { 
        return description; 
    }

    // setters for fields that can be updated
    public void setAppointmentDate(Date newDate) {
        setAppointmentDateInternal(newDate);
    }

    public void setDescription(String newDescription) {
        setDescriptionInternal(newDescription);
    }

    // helper for id checks
    private static void validateId(String id) {
        if (id == null) throw new IllegalArgumentException("ID cannot be null.");
        if (id.length() > 10) throw new IllegalArgumentException("ID cannot be longer than 10 characters.");
    }

    // helper for date checks
    private void setAppointmentDateInternal(Date date) {
        if (date == null) throw new IllegalArgumentException("Date cannot be null.");
        if (date.before(new Date())) throw new IllegalArgumentException("Date cannot be in the past.");
        this.appointmentDate = new Date(date.getTime());
    }

    // helper for description checks
    private void setDescriptionInternal(String desc) {
        if (desc == null) throw new IllegalArgumentException("Description cannot be null.");
        if (desc.length() > 50) throw new IllegalArgumentException("Description cannot be longer than 50 characters.");
        this.description = desc;
    }

    // equality check based only on id
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Appointment)) return false;
        Appointment that = (Appointment) o;
        return appointmentId.equals(that.appointmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId);
    }
}
