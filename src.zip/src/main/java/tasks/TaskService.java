/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Task Service
 * File: TaskService.java
 *
 * In-memory service for managing Task objects.
 * Requirements:
 *  - Add tasks with unique IDs
 *  - Delete tasks by ID
 *  - Update name and description by ID
 * Notes:
 *  - Uniqueness is enforced here
 *  - Validation of fields is delegated to Task
 */

package tasks;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    // Internal store keyed by unique taskId
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a Task instance to the service.
     * Enforces unique IDs.
     * @param task non-null Task
     * @throws IllegalArgumentException if task is null or ID already exists
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task ID already exists: " + id);
        }
        tasks.put(id, task);
    }

    /**
     * Convenience overload to build and store a Task in one call.
     * Uses Task constructor for validation.
     * @return the created Task (also stored)
     */
    public Task addTask(String taskId, String name, String description) {
        Task t = new Task(taskId, name, description);
        addTask(t);
        return t;
    }

    /**
     * Retrieves a Task by ID.
     * @return Task if present, otherwise null
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    /**
     * Deletes a Task by ID.
     * @return true if removed; false if not found
     */
    public boolean deleteTask(String taskId) {
        return tasks.remove(taskId) != null;
    }

    /**
     * Updates the name field of a Task identified by ID.
     * Validation is handled by Task#setName.
     * @throws IllegalArgumentException if ID not found or name invalid
     */
    public void updateTaskName(String taskId, String newName) {
        Task t = getExisting(taskId);
        t.setName(newName);
    }

    /**
     * Updates the description field of a Task identified by ID.
     * Validation is handled by Task#setDescription.
     * @throws IllegalArgumentException if ID not found or description invalid
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        Task t = getExisting(taskId);
        t.setDescription(newDescription);
    }

    // --- Helper: fetch an existing task or throw with a clear message ---
    private Task getExisting(String taskId) {
        Task t = tasks.get(taskId);
        if (t == null) {
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }
        return t;
    }
}
