/*
 * Author: Michael Ford
 * Course: CS 320 - SNHU
 * Module: 6 - Project 1 - Task Service
 * File: Task.java
 *
 * This class defines the Task object for the project.
 * It enforces requirements such as field length limits
 * and non-null values. The taskId is immutable while
 * name and description can be updated with validation.
 */

package tasks;

public class Task {

    // Constants for field length requirements
    public static final int MAX_ID_LENGTH   = 10;
    public static final int MAX_NAME_LENGTH = 20;
    public static final int MAX_DESC_LENGTH = 50;

    private final String taskId;   // Required, non-null, ≤ 10 chars, not updatable
    private String name;           // Required, non-null, ≤ 20 chars, updatable
    private String description;    // Required, non-null, ≤ 50 chars, updatable

    /**
     * Constructs a Task that satisfies all constraints.
     * @param taskId required, ≤ 10 chars, non-null
     * @param name required, ≤ 20 chars, non-null
     * @param description required, ≤ 50 chars, non-null
     * @throws IllegalArgumentException if constraints are violated
     */
    public Task(String taskId, String name, String description) {
        this.taskId = validateId(taskId);
        this.name = validateName(name);
        this.description = validateDescription(description);
    }

    // --- Validation helpers ---
    private static String validateId(String id) {
        if (id == null) {
            throw new IllegalArgumentException("taskId cannot be null.");
        }
        if (id.length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException("taskId length must be ≤ " + MAX_ID_LENGTH);
        }
        return id;
    }

    private static String validateName(String nm) {
        if (nm == null) {
            throw new IllegalArgumentException("name cannot be null.");
        }
        if (nm.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException("name length must be ≤ " + MAX_NAME_LENGTH);
        }
        return nm;
    }

    private static String validateDescription(String desc) {
        if (desc == null) {
            throw new IllegalArgumentException("description cannot be null.");
        }
        if (desc.length() > MAX_DESC_LENGTH) {
            throw new IllegalArgumentException("description length must be ≤ " + MAX_DESC_LENGTH);
        }
        return desc;
    }

    // --- Getters ---
    public String getTaskId() {
        return taskId; // Immutable
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // --- Updaters ---
    public void setName(String name) {
        this.name = validateName(name);
    }

    public void setDescription(String description) {
        this.description = validateDescription(description);
    }

    @Override
    public String toString() {
        return "Task{id='" + taskId + "', name='" + name + "', description='" + description + "'}";
    }
}
